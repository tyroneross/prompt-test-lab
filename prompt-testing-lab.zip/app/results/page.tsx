"use client"

import { useState, useEffect } from "react"
import {
  GitBranch,
  Check,
  Crown,
  UserIcon,
  Target,
  DollarSign,
  Copy,
  Zap,
  Clock,
  CoinsIcon as Tokens,
  Star,
  Trophy,
  BarChart3,
  ChevronDown,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

interface TestVariant {
  id: number
  label: string
  prompt: string
  selected: boolean
  score?: number
  metrics?: {
    readability: number
    engagement: number
    accuracy: number
  }
}

interface OutputData {
  formatted: string
  json: any
  raw: string
  latency: number
  tokens: number
}

interface App {
  id: string
  name: string
  version: string
}

export default function TestResults() {
  const [selectedApp, setSelectedApp] = useState("Atomize News")
  const [outputFormat, setOutputFormat] = useState<"formatted" | "json" | "raw">("formatted")
  const [selectedWinner, setSelectedWinner] = useState<number | null>(null)
  const [showMetrics, setShowMetrics] = useState(false)
  const [currentView] = useState<"dashboard" | "results">("results")
  const [confirmingWinner, setConfirmingWinner] = useState<number | null>(null)

  // State that will be populated from dashboard data
  const [inputText, setInputText] = useState(
    "Breaking: OpenAI releases GPT-5 with revolutionary reasoning capabilities",
  )
  const [currentPrompt, setCurrentPrompt] = useState("Summarize this news in an engaging headline and brief:")
  const [testPrompts, setTestPrompts] = useState<TestVariant[]>([])
  const [outputs, setOutputs] = useState<Record<string | number, OutputData>>({})

  // Load test data from dashboard
  useEffect(() => {
    const savedTestData = localStorage.getItem("testData")
    if (savedTestData) {
      try {
        const testData = JSON.parse(savedTestData)
        setInputText(testData.inputText || inputText)
        setCurrentPrompt(testData.currentPrompt || currentPrompt)

        // Add scores and metrics to test prompts
        const promptsWithScores = testData.testPrompts.map((prompt: any, index: number) => ({
          ...prompt,
          score: [87, 94, 76][index] || 80,
          metrics: {
            readability: [92, 88, 78][index] || 85,
            engagement: [85, 96, 72][index] || 80,
            accuracy: [84, 98, 79][index] || 82,
          },
        }))

        setTestPrompts(promptsWithScores)
        setOutputs(testData.outputs || outputs)

        // Clear the saved data after loading
        localStorage.removeItem("testData")
      } catch (error) {
        console.error("Error loading test data:", error)
        // Fall back to default data if parsing fails
        setTestPrompts([
          {
            id: 1,
            label: "Test Variant A",
            prompt: "Transform this breaking news into a compelling story lead that hooks readers:",
            selected: false,
            score: 87,
            metrics: { readability: 92, engagement: 85, accuracy: 84 },
          },
          {
            id: 2,
            label: "Test Variant B",
            prompt: "Create an attention-grabbing headline and summary for this news story:",
            selected: false,
            score: 94,
            metrics: { readability: 88, engagement: 96, accuracy: 98 },
          },
          {
            id: 3,
            label: "Test Variant C",
            prompt: "Write a captivating news brief that will make readers want to learn more:",
            selected: false,
            score: 76,
            metrics: { readability: 78, engagement: 72, accuracy: 79 },
          },
        ])
      }
    } else {
      // Default fallback data
      setTestPrompts([
        {
          id: 1,
          label: "Test Variant A",
          prompt: "Transform this breaking news into a compelling story lead that hooks readers:",
          selected: false,
          score: 87,
          metrics: { readability: 92, engagement: 85, accuracy: 84 },
        },
        {
          id: 2,
          label: "Test Variant B",
          prompt: "Create an attention-grabbing headline and summary for this news story:",
          selected: false,
          score: 94,
          metrics: { readability: 88, engagement: 96, accuracy: 98 },
        },
        {
          id: 3,
          label: "Test Variant C",
          prompt: "Write a captivating news brief that will make readers want to learn more:",
          selected: false,
          score: 76,
          metrics: { readability: 78, engagement: 72, accuracy: 79 },
        },
      ])

      setOutputs({
        current: {
          formatted:
            "🚀 GPT-5 Breakthrough: OpenAI's Latest AI Shows Human-Level Reasoning\n\nOpenAI has unveiled GPT-5, marking a significant leap in artificial intelligence capabilities with enhanced logical reasoning that rivals human cognition.",
          json: {
            headline: "🚀 GPT-5 Breakthrough: OpenAI's Latest AI Shows Human-Level Reasoning",
            summary:
              "OpenAI has unveiled GPT-5, marking a significant leap in artificial intelligence capabilities with enhanced logical reasoning that rivals human cognition.",
            confidence: 0.92,
            categories: ["technology", "ai", "breakthrough"],
          },
          raw: "RESPONSE_START\n🚀 GPT-5 Breakthrough: OpenAI's Latest AI Shows Human-Level Reasoning\n\nOpenAI has unveiled GPT-5, marking a significant leap in artificial intelligence capabilities with enhanced logical reasoning that rivals human cognition.\nRESPONSE_END\n\nMETA: tokens=156, model=gpt-4o, temp=0.7",
          latency: 1247,
          tokens: 156,
        },
        1: {
          formatted:
            "The AI world just shifted forever. OpenAI dropped GPT-5 today, and early tests show it can reason through complex problems like a graduate student.\n\nThis isn't just another incremental update—it's the breakthrough researchers have been chasing for years.",
          json: {
            opening: "The AI world just shifted forever.",
            body: "OpenAI dropped GPT-5 today, and early tests show it can reason through complex problems like a graduate student.",
            conclusion:
              "This isn't just another incremental update—it's the breakthrough researchers have been chasing for years.",
            tone: "dramatic",
            hook_strength: 0.89,
          },
          raw: "RESPONSE_START\nThe AI world just shifted forever. OpenAI dropped GPT-5 today, and early tests show it can reason through complex problems like a graduate student.\n\nThis isn't just another incremental update—it's the breakthrough researchers have been chasing for years.\nRESPONSE_END\n\nMETA: tokens=203, model=gpt-4o, temp=0.8",
          latency: 1893,
          tokens: 203,
        },
        2: {
          formatted:
            "🔥 GAME CHANGER: OpenAI's GPT-5 Achieves Human-Level Reasoning\n\nIn a stunning development that could reshape the AI landscape, OpenAI has released GPT-5 with unprecedented reasoning capabilities that match human cognitive performance.",
          json: {
            headline: "🔥 GAME CHANGER: OpenAI's GPT-5 Achieves Human-Level Reasoning",
            summary:
              "OpenAI has released GPT-5 with unprecedented reasoning capabilities that match human cognitive performance.",
            urgency: "high",
            impact_score: 0.95,
          },
          raw: "RESPONSE_START\n🔥 GAME CHANGER: OpenAI's GPT-5 Achieves Human-Level Reasoning\n\nIn a stunning development that could reshape the AI landscape, OpenAI has released GPT-5 with unprecedented reasoning capabilities that match human cognitive performance.\nRESPONSE_END\n\nMETA: tokens=178, model=gpt-4o, temp=0.6",
          latency: 1456,
          tokens: 178,
        },
        3: {
          formatted:
            "OpenAI Releases GPT-5 with Advanced Reasoning\n\nThe latest version of OpenAI's language model demonstrates significant improvements in logical reasoning and problem-solving capabilities, representing a major step forward in AI development.",
          json: {
            title: "OpenAI Releases GPT-5 with Advanced Reasoning",
            content:
              "The latest version of OpenAI's language model demonstrates significant improvements in logical reasoning and problem-solving capabilities, representing a major step forward in AI development.",
            tone: "professional",
            complexity: "medium",
          },
          raw: "RESPONSE_START\nOpenAI Releases GPT-5 with Advanced Reasoning\n\nThe latest version of OpenAI's language model demonstrates significant improvements in logical reasoning and problem-solving capabilities, representing a major step forward in AI development.\nRESPONSE_END\n\nMETA: tokens=142, model=gpt-4o, temp=0.5",
          latency: 1123,
          tokens: 142,
        },
      })
    }
  }, [])

  const [userData] = useState({ name: "Alex Chen", canDeploy: true, email: "alex@atomize.ai" })
  const [apps] = useState([
    { id: "atomize", name: "Atomize News", version: "v1.2.1" },
    { id: "summarizer", name: "Content Summarizer", version: "v0.8.3" },
  ])
  const [costData] = useState({ thisMonth: 18.73, limit: 25.0, lastTest: 0.34 })

  const selectWinner = (variantId: number) => {
    setSelectedWinner(variantId)
    setConfirmingWinner(null)
    toast({
      title: "Winner selected",
      description: `${testPrompts.find((v) => v.id === variantId)?.label} has been selected as the winner.`,
    })
  }

  const handleWinnerSelection = (variantId: number) => {
    setConfirmingWinner(variantId)
  }

  const copyPrompt = (prompt: string) => {
    navigator.clipboard.writeText(prompt)
    toast({
      title: "Copied to clipboard",
      description: "Prompt has been copied to your clipboard.",
    })
  }

  const proceedToDeploy = () => {
    if (selectedWinner) {
      // In a real app, you'd pass the selected variant data
      window.location.href = `/deploy?winner=${selectedWinner}`
    }
  }

  // Sort variants by score for leaderboard
  const sortedVariants = [...testPrompts].sort((a, b) => (b.score || 0) - (a.score || 0))
  const bestVariant = sortedVariants[0]

  return (
    <div className="min-h-screen bg-background">
      {/* Fixed Header */}
      <div className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center justify-between px-6">
          {/* Left side - Navigation toggle and info */}
          <div className="flex items-center gap-4">
            <div className="flex items-center bg-muted rounded-lg p-1">
              <Button
                variant={currentView === "dashboard" ? "default" : "ghost"}
                size="sm"
                onClick={() => (window.location.href = "/")}
                className="px-4"
              >
                Dashboard
              </Button>
              <Button variant={currentView === "results" ? "default" : "ghost"} size="sm" className="px-4" disabled>
                Results
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
                <UserIcon className="h-4 w-4 text-white" />
              </div>
              <span className="text-sm font-medium">{userData.name}</span>
            </div>

            <div className="flex items-center gap-2">
              <Select value={selectedApp} onValueChange={setSelectedApp}>
                <SelectTrigger className="w-48">
                  <div className="flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    <SelectValue />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  {apps.map((app) => (
                    <SelectItem key={app.id} value={app.name}>
                      {app.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Badge variant="outline">{apps.find((a) => a.name === selectedApp)?.version || "v1.0.0"}</Badge>
            </div>
          </div>

          {/* Right side - Actions and info */}
          <div className="flex items-center gap-3">
            <Badge
              variant={costData.thisMonth > costData.limit * 0.8 ? "destructive" : "secondary"}
              className="flex items-center gap-1"
            >
              <DollarSign className="h-3 w-3" />${costData.thisMonth}/${costData.limit}
            </Badge>

            {userData.canDeploy && (
              <Badge className="bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700 flex items-center gap-1">
                <Crown className="h-3 w-3" />
                Builder
              </Badge>
            )}

            {selectedWinner && (
              <Button onClick={proceedToDeploy} className="bg-green-600 hover:bg-green-700">
                <Zap className="mr-2 h-4 w-4" />
                Deploy Winner
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 max-w-7xl mx-auto">
        <div className="space-y-6">
          {/* Scoring Methodology - Collapsible */}
          <Collapsible>
            <Card className="border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-900/20">
              <CollapsibleTrigger asChild>
                <CardHeader className="pb-3 cursor-pointer hover:bg-blue-100/50 dark:hover:bg-blue-800/30 transition-colors">
                  <CardTitle className="text-base flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="h-4 w-4 text-blue-600" />
                      Scoring Methodology
                    </div>
                    <ChevronDown className="h-4 w-4 text-blue-600 transition-transform group-data-[state=open]:rotate-180" />
                  </CardTitle>
                </CardHeader>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">Readability (30%)</h4>
                      <p className="text-blue-700 dark:text-blue-300">
                        Based on Flesch-Kincaid Grade Level and sentence complexity. Industry standard for content
                        accessibility.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">Engagement (40%)</h4>
                      <p className="text-blue-700 dark:text-blue-300">
                        Measures hook strength, emotional impact, and click-through potential using proven copywriting
                        principles.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-1">Accuracy (30%)</h4>
                      <p className="text-blue-700 dark:text-blue-300">
                        Semantic similarity to source content and factual consistency using BERT-based evaluation
                        models.
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-blue-200 dark:border-blue-700">
                    <p className="text-xs text-blue-600 dark:text-blue-400">
                      <strong>Overall Score:</strong> Weighted average based on percentages above. Scores ≥90% indicate
                      exceptional performance, 80-89% good performance, &lt;80% needs improvement.
                    </p>
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Card>
          </Collapsible>

          {/* Header with Stats */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <GitBranch className="h-6 w-6 text-blue-600" />
              <h1 className="text-3xl font-bold">Test Results</h1>
              <Badge variant="secondary">{testPrompts.length + 1} variants tested</Badge>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Best Score</p>
                <p className="text-2xl font-bold text-green-600">{bestVariant?.score || 0}%</p>
              </div>
              <Button variant="outline" onClick={() => setShowMetrics(!showMetrics)}>
                <BarChart3 className="mr-2 h-4 w-4" />
                {showMetrics ? "Hide" : "Show"} Metrics in Cards
              </Button>
            </div>
          </div>

          {/* Winner Selection Banner */}
          {selectedWinner && (
            <Card className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <Trophy className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-green-900 dark:text-green-100">
                        Winner Selected: {testPrompts.find((v) => v.id === selectedWinner)?.label}
                      </h3>
                      <p className="text-sm text-green-700 dark:text-green-300">
                        Score: {testPrompts.find((v) => v.id === selectedWinner)?.score}% • Ready for deployment
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyPrompt(testPrompts.find((v) => v.id === selectedWinner)?.prompt || "")}
                    >
                      <Copy className="mr-2 h-4 w-4" />
                      Copy Prompt
                    </Button>
                    <Button onClick={proceedToDeploy} className="bg-green-600 hover:bg-green-700">
                      <Zap className="mr-2 h-4 w-4" />
                      Deploy Now
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Label htmlFor="format-select">Output Format:</Label>
                <Select
                  value={outputFormat}
                  onValueChange={(value: "formatted" | "json" | "raw") => setOutputFormat(value)}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="formatted">Formatted</SelectItem>
                    <SelectItem value="json">JSON</SelectItem>
                    <SelectItem value="raw">Raw</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="text-sm text-muted-foreground">
              {selectedWinner ? "1 winner selected" : "Select a winner to proceed"}
            </div>
          </div>

          <Tabs defaultValue="comparison" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="comparison">Comparison View</TabsTrigger>
              <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
              <TabsTrigger value="metrics">Detailed Metrics</TabsTrigger>
            </TabsList>

            <TabsContent value="comparison" className="space-y-6">
              {/* Variants Grid */}
              <div className="grid grid-cols-1 xl:grid-cols-2 2xl:grid-cols-3 gap-6">
                {/* Current Variant */}
                <Card className="border-2">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        Current (Live)
                        <Badge className="bg-blue-100 text-blue-700">v1.2.1</Badge>
                      </CardTitle>
                    </div>
                    <div className="text-xs font-mono bg-muted p-2 rounded text-muted-foreground">{currentPrompt}</div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-xs text-muted-foreground font-medium">
                        {outputs.current?.latency}ms • {outputs.current?.tokens} tokens
                      </span>
                    </div>
                    <div className="text-sm leading-relaxed">
                      {outputFormat === "formatted" && outputs.current?.formatted}
                      {outputFormat === "json" && (
                        <pre className="font-mono text-xs overflow-auto">
                          {JSON.stringify(outputs.current?.json, null, 2)}
                        </pre>
                      )}
                      {outputFormat === "raw" && (
                        <pre className="font-mono text-xs whitespace-pre-wrap">{outputs.current?.raw}</pre>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Test Variants */}
                {testPrompts.map((variant) => {
                  const output = outputs[variant.id]
                  if (!output) return null

                  const isWinner = selectedWinner === variant.id
                  const isTopPerformer = variant.id === bestVariant?.id

                  return (
                    <Card
                      key={variant.id}
                      className={`border-2 transition-all duration-200 hover:shadow-lg ${
                        isWinner
                          ? "border-green-300 ring-2 ring-green-100 dark:border-green-600 dark:ring-green-900/50 bg-green-50 dark:bg-green-900/10"
                          : isTopPerformer
                            ? "border-amber-300 ring-2 ring-amber-100 dark:border-amber-600 dark:ring-amber-900/50"
                            : "border-border hover:border-blue-200"
                      }`}
                    >
                      <CardHeader className="pb-3 relative">
                        {/* Winner Selection Button - Top Left */}
                        <div className="absolute top-3 left-3 z-10">
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant={isWinner ? "default" : "outline"}
                                size="sm"
                                className={`h-7 px-2 text-xs ${
                                  isWinner
                                    ? "bg-green-600 hover:bg-green-700 text-white"
                                    : "hover:bg-blue-50 hover:border-blue-300"
                                }`}
                                onClick={() => handleWinnerSelection(variant.id)}
                              >
                                {isWinner ? (
                                  <>
                                    <Check className="mr-1 h-3 w-3" />
                                    Winner
                                  </>
                                ) : (
                                  "Select"
                                )}
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Select Winner</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to select <strong>{variant.label}</strong> as the winner? This
                                  will mark it as the best performing variant for deployment.
                                  {selectedWinner && selectedWinner !== variant.id && (
                                    <span className="block mt-2 text-amber-600">
                                      This will replace your current selection:{" "}
                                      {testPrompts.find((v) => v.id === selectedWinner)?.label}
                                    </span>
                                  )}
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => selectWinner(variant.id)}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  Select as Winner
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>

                        <div className="flex items-center justify-between pt-6">
                          <CardTitle className="text-base flex items-center gap-2">
                            {variant.label}
                            {isTopPerformer && <Star className="h-4 w-4 text-amber-500" />}
                            {isWinner && <Trophy className="h-4 w-4 text-green-600" />}
                          </CardTitle>
                          <div className="flex items-center gap-2">
                            {variant.score && (
                              <Badge
                                variant={
                                  variant.score >= 90 ? "default" : variant.score >= 80 ? "secondary" : "outline"
                                }
                                className={
                                  variant.score >= 90
                                    ? "bg-green-100 text-green-700"
                                    : variant.score >= 80
                                      ? "bg-blue-100 text-blue-700"
                                      : ""
                                }
                              >
                                {variant.score}%
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="text-xs font-mono bg-muted p-2 rounded text-muted-foreground">
                          {variant.prompt}
                        </div>
                        {showMetrics && variant.metrics && (
                          <div className="space-y-2 pt-2 border-t border-muted mt-2">
                            <p className="text-xs font-medium text-muted-foreground mb-2">Performance Breakdown</p>
                            <div className="flex justify-between text-xs">
                              <span>Readability</span>
                              <span className="font-medium">{variant.metrics.readability}%</span>
                            </div>
                            <Progress value={variant.metrics.readability} className="h-1" />
                            <div className="flex justify-between text-xs">
                              <span>Engagement</span>
                              <span className="font-medium">{variant.metrics.engagement}%</span>
                            </div>
                            <Progress value={variant.metrics.engagement} className="h-1" />
                            <div className="flex justify-between text-xs">
                              <span>Accuracy</span>
                              <span className="font-medium">{variant.metrics.accuracy}%</span>
                            </div>
                            <Progress value={variant.metrics.accuracy} className="h-1" />
                          </div>
                        )}
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-2 mb-3">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-xs text-muted-foreground font-medium">
                            {output.latency}ms • {output.tokens} tokens
                          </span>
                        </div>
                        <div className="text-sm leading-relaxed">
                          {outputFormat === "formatted" && output.formatted}
                          {outputFormat === "json" && (
                            <pre className="font-mono text-xs overflow-auto">
                              {JSON.stringify(output.json, null, 2)}
                            </pre>
                          )}
                          {outputFormat === "raw" && (
                            <pre className="font-mono text-xs whitespace-pre-wrap">{output.raw}</pre>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </TabsContent>

            <TabsContent value="leaderboard" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="h-5 w-5 text-amber-500" />
                    Performance Leaderboard
                  </CardTitle>
                  <CardDescription>Variants ranked by overall performance score</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {sortedVariants.map((variant, index) => (
                      <div
                        key={variant.id}
                        className={`flex items-center justify-between p-4 rounded-lg border transition-all duration-200 ${
                          selectedWinner === variant.id
                            ? "border-green-300 bg-green-50 dark:border-green-600 dark:bg-green-900/20"
                            : "border-border hover:border-blue-200 hover:bg-muted/50"
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                              index === 0
                                ? "bg-amber-100 text-amber-700"
                                : index === 1
                                  ? "bg-gray-100 text-gray-700"
                                  : index === 2
                                    ? "bg-orange-100 text-orange-700"
                                    : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {index + 1}
                          </div>
                          <div>
                            <h3 className="font-medium flex items-center gap-2">
                              {variant.label}
                              {index === 0 && <Crown className="h-4 w-4 text-amber-500" />}
                              {selectedWinner === variant.id && <Check className="h-4 w-4 text-green-600" />}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {variant.metrics && (
                                <>
                                  Readability: {variant.metrics.readability}% • Engagement: {variant.metrics.engagement}
                                  % • Accuracy: {variant.metrics.accuracy}%
                                </>
                              )}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <div className="text-2xl font-bold text-green-600">{variant.score}%</div>
                            <div className="text-xs text-muted-foreground">Overall Score</div>
                          </div>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant={selectedWinner === variant.id ? "default" : "outline"}
                                size="sm"
                                onClick={() => handleWinnerSelection(variant.id)}
                              >
                                {selectedWinner === variant.id ? (
                                  <>
                                    <Check className="mr-2 h-4 w-4" />
                                    Winner
                                  </>
                                ) : (
                                  "Select"
                                )}
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Select Winner</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to select <strong>{variant.label}</strong> as the winner? This
                                  will mark it as the best performing variant for deployment.
                                  {selectedWinner && selectedWinner !== variant.id && (
                                    <span className="block mt-2 text-amber-600">
                                      This will replace your current selection:{" "}
                                      {testPrompts.find((v) => v.id === selectedWinner)?.label}
                                    </span>
                                  )}
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => selectWinner(variant.id)}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  Select as Winner
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="metrics" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {testPrompts.map((variant) => (
                  <Card key={variant.id}>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center justify-between">
                        {variant.label}
                        <Badge variant="outline">{variant.score}%</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {variant.metrics && (
                        <>
                          <div>
                            <div className="flex justify-between text-sm mb-1">
                              <span>Readability</span>
                              <span>{variant.metrics.readability}%</span>
                            </div>
                            <Progress value={variant.metrics.readability} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between text-sm mb-1">
                              <span>Engagement</span>
                              <span>{variant.metrics.engagement}%</span>
                            </div>
                            <Progress value={variant.metrics.engagement} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between text-sm mb-1">
                              <span>Accuracy</span>
                              <span>{variant.metrics.accuracy}%</span>
                            </div>
                            <Progress value={variant.metrics.accuracy} className="h-2" />
                          </div>
                        </>
                      )}
                      <Separator />
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>{outputs[variant.id]?.latency}ms</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Tokens className="h-3 w-3" />
                          <span>{outputs[variant.id]?.tokens} tokens</span>
                        </div>
                      </div>
                      <Button
                        variant={selectedWinner === variant.id ? "default" : "outline"}
                        size="sm"
                        className="w-full"
                      >
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <span className="w-full">
                              {selectedWinner === variant.id ? (
                                <>
                                  <Check className="mr-2 h-4 w-4" />
                                  Selected Winner
                                </>
                              ) : (
                                "Select as Winner"
                              )}
                            </span>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Select Winner</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to select <strong>{variant.label}</strong> as the winner? This
                                will mark it as the best performing variant for deployment.
                                {selectedWinner && selectedWinner !== variant.id && (
                                  <span className="block mt-2 text-amber-600">
                                    This will replace your current selection:{" "}
                                    {testPrompts.find((v) => v.id === selectedWinner)?.label}
                                  </span>
                                )}
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => selectWinner(variant.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                Select as Winner
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
