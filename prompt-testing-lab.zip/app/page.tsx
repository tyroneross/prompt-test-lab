"use client"

import { useState, useRef } from "react"
import {
  Play,
  GitBranch,
  Check,
  X,
  Upload,
  Code,
  FileText,
  Zap,
  Crown,
  UserIcon,
  DollarSign,
  Maximize2,
  Minimize2,
  Plus,
  Loader2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"

interface TestVariant {
  id: number
  label: string
  prompt: string
  selected: boolean
}

interface OutputData {
  formatted: string
  json: any
  raw: string
  latency: number
  tokens: number
}

interface App {
  id: string
  name: string
  version: string
}

interface CostData {
  thisMonth: number
  limit: number
  lastTest: number
}

export default function PromptTestingLab() {
  // Core state
  const [currentView, setCurrentView] = useState<"dashboard" | "deploy">("dashboard")
  const [selectedApp, setSelectedApp] = useState("Atomize News")
  const [testRunning, setTestRunning] = useState(false)
  const [testCompleted, setTestCompleted] = useState(false)
  const [deploySuccess, setDeploySuccess] = useState(false)
  const [undoTimer, setUndoTimer] = useState<number | null>(null)
  const [outputFormat, setOutputFormat] = useState<"formatted" | "json" | "raw">("formatted")
  const [expandedPrompts, setExpandedPrompts] = useState<Record<number, boolean>>({})

  // Test data
  const [inputText, setInputText] = useState(
    "Breaking: OpenAI releases GPT-5 with revolutionary reasoning capabilities",
  )
  const [currentPrompt, setCurrentPrompt] = useState("Summarize this news in an engaging headline and brief:")
  const [testPrompts, setTestPrompts] = useState<TestVariant[]>([
    {
      id: 1,
      label: "Test Variant A",
      prompt: "Transform this breaking news into a compelling story lead that hooks readers:",
      selected: false,
    },
    {
      id: 2,
      label: "Test Variant B",
      prompt: "Create an attention-grabbing headline and summary for this news story:",
      selected: false,
    },
    {
      id: 3,
      label: "Test Variant C",
      prompt: "Write a captivating news brief that will make readers want to learn more:",
      selected: false,
    },
  ])

  // Mock data
  const [outputs] = useState<Record<string | number, OutputData>>({
    current: {
      formatted:
        "🚀 GPT-5 Breakthrough: OpenAI's Latest AI Shows Human-Level Reasoning\n\nOpenAI has unveiled GPT-5, marking a significant leap in artificial intelligence capabilities with enhanced logical reasoning that rivals human cognition.",
      json: {
        headline: "🚀 GPT-5 Breakthrough: OpenAI's Latest AI Shows Human-Level Reasoning",
        summary:
          "OpenAI has unveiled GPT-5, marking a significant leap in artificial intelligence capabilities with enhanced logical reasoning that rivals human cognition.",
        confidence: 0.92,
        categories: ["technology", "ai", "breakthrough"],
      },
      raw: "RESPONSE_START\n🚀 GPT-5 Breakthrough: OpenAI's Latest AI Shows Human-Level Reasoning\n\nOpenAI has unveiled GPT-5, marking a significant leap in artificial intelligence capabilities with enhanced logical reasoning that rivals human cognition.\nRESPONSE_END\n\nMETA: tokens=156, model=gpt-4o, temp=0.7",
      latency: 1247,
      tokens: 156,
    },
    1: {
      formatted:
        "The AI world just shifted forever. OpenAI dropped GPT-5 today, and early tests show it can reason through complex problems like a graduate student.\n\nThis isn't just another incremental update—it's the breakthrough researchers have been chasing for years.",
      json: {
        opening: "The AI world just shifted forever.",
        body: "OpenAI dropped GPT-5 today, and early tests show it can reason through complex problems like a graduate student.",
        conclusion:
          "This isn't just another incremental update—it's the breakthrough researchers have been chasing for years.",
        tone: "dramatic",
        hook_strength: 0.89,
      },
      raw: "RESPONSE_START\nThe AI world just shifted forever. OpenAI dropped GPT-5 today, and early tests show it can reason through complex problems like a graduate student.\n\nThis isn't just another incremental update—it's the breakthrough researchers have been chasing for years.\nRESPONSE_END\n\nMETA: tokens=203, model=gpt-4o, temp=0.8",
      latency: 1893,
      tokens: 203,
    },
    2: {
      formatted:
        "🔥 GAME CHANGER: OpenAI's GPT-5 Achieves Human-Level Reasoning\n\nIn a stunning development that could reshape the AI landscape, OpenAI has released GPT-5 with unprecedented reasoning capabilities that match human cognitive performance.",
      json: {
        headline: "🔥 GAME CHANGER: OpenAI's GPT-5 Achieves Human-Level Reasoning",
        summary:
          "In a stunning development that could reshape the AI landscape, OpenAI has released GPT-5 with unprecedented reasoning capabilities that match human cognitive performance.",
        urgency: "high",
        impact_score: 0.95,
      },
      raw: "RESPONSE_START\n🔥 GAME CHANGER: OpenAI's GPT-5 Achieves Human-Level Reasoning\n\nIn a stunning development that could reshape the AI landscape, OpenAI has released GPT-5 with unprecedented reasoning capabilities that match human cognitive performance.\nRESPONSE_END\n\nMETA: tokens=178, model=gpt-4o, temp=0.6",
      latency: 1456,
      tokens: 178,
    },
    3: {
      formatted:
        "OpenAI Releases GPT-5 with Advanced Reasoning\n\nThe latest version of OpenAI's language model demonstrates significant improvements in logical reasoning and problem-solving capabilities, representing a major step forward in AI development.",
      json: {
        title: "OpenAI Releases GPT-5 with Advanced Reasoning",
        content:
          "The latest version of OpenAI's language model demonstrates significant improvements in logical reasoning and problem-solving capabilities, representing a major step forward in AI development.",
        tone: "professional",
        complexity: "medium",
      },
      raw: "RESPONSE_START\nOpenAI Releases GPT-5 with Advanced Reasoning\n\nThe latest version of OpenAI's language model demonstrates significant improvements in logical reasoning and problem-solving capabilities, representing a major step forward in AI development.\nRESPONSE_END\n\nMETA: tokens=142, model=gpt-4o, temp=0.5",
      latency: 1123,
      tokens: 142,
    },
  })

  const [userData] = useState({ name: "Alex Chen", canDeploy: true, email: "alex@atomize.ai" })
  const [apps] = useState([
    { id: "atomize", name: "Atomize News", version: "v1.2.1" },
    { id: "summarizer", name: "Content Summarizer", version: "v0.8.3" },
  ])
  const [costData] = useState({ thisMonth: 18.73, limit: 25.0, lastTest: 0.34 })

  const fileInputRef = useRef<HTMLInputElement>(null)

  // UI handlers
  const startTest = () => {
    setTestRunning(true)
    // Pass the test data to results page via localStorage for demo purposes
    localStorage.setItem(
      "testData",
      JSON.stringify({
        inputText,
        currentPrompt,
        testPrompts,
        outputs,
      }),
    )
    setTimeout(() => {
      setTestRunning(false)
      setTestCompleted(true)
      // Navigate to results page instead of changing view
      window.location.href = "/results"
    }, 3000)
  }

  const deployPrompt = () => {
    setDeploySuccess(true)
    setUndoTimer(300) // 5 minutes
    toast({
      title: "Deployment successful",
      description: "v1.2.2 has been deployed successfully.",
    })
    setTimeout(() => setDeploySuccess(false), 8000)
  }

  const selectVariant = (variantId: number) => {
    setTestPrompts((prev) => prev.map((v) => ({ ...v, selected: v.id === variantId })))
  }

  const addVariant = () => {
    const newId = Math.max(...testPrompts.map((v) => v.id)) + 1
    const nextLetter = String.fromCharCode(65 + testPrompts.length)
    setTestPrompts((prev) => [
      ...prev,
      {
        id: newId,
        label: `Test Variant ${nextLetter}`,
        prompt: "",
        selected: false,
      },
    ])
  }

  const removeVariant = (variantId: number) => {
    if (testPrompts.length > 1) {
      setTestPrompts((prev) => prev.filter((v) => v.id !== variantId))
    }
  }

  const updatePrompt = (variantId: number, newPrompt: string) => {
    setTestPrompts((prev) => prev.map((v) => (v.id === variantId ? { ...v, prompt: newPrompt } : v)))
  }

  const togglePromptExpansion = (variantId: number) => {
    setExpandedPrompts((prev) => ({
      ...prev,
      [variantId]: !prev[variantId],
    }))
  }

  const handleFileUpload = () => {
    fileInputRef.current?.click()
  }

  // Deploy Review View
  const DeployView = () => {
    const selectedVariant = testPrompts.find((v) => v.selected)

    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Zap className="h-6 w-6 text-blue-600" />
            <h2 className="text-2xl font-semibold">Deploy Review</h2>
          </div>
          <Button variant="outline" onClick={() => (window.location.href = "/results")}>
            Back to Results
          </Button>
        </div>

        {/* Deploy Preview */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">{selectedApp} → v1.2.2</CardTitle>
                <CardDescription>Deploying {selectedVariant?.label} as new base prompt</CardDescription>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium">Impact Preview</p>
                <p className="text-sm text-muted-foreground">~47% output change detected</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Prompt Changes */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Code className="h-4 w-4" />
                  Prompt Changes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Current</Label>
                    <div className="mt-2 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                      <pre className="text-sm font-mono whitespace-pre-wrap">{currentPrompt}</pre>
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">New</Label>
                    <div className="mt-2 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                      <pre className="text-sm font-mono whitespace-pre-wrap">{selectedVariant?.prompt || ""}</pre>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Output Preview */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Output Preview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Current</Label>
                    <div className="mt-2 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                      <div className="text-sm whitespace-pre-wrap">{outputs.current?.formatted || ""}</div>
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">New</Label>
                    <div className="mt-2 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                      <div className="text-sm whitespace-pre-wrap">
                        {outputs[selectedVariant?.id || 1]?.formatted || ""}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </CardContent>
        </Card>

        {/* Deploy Button */}
        <div className="flex justify-center">
          <Button onClick={deployPrompt} className="bg-green-600 hover:bg-green-700" size="lg">
            <Zap className="mr-2 h-4 w-4" />
            Deploy v1.2.2
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Fixed Header */}
      <div className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center justify-between px-6">
          {/* Left side - Navigation toggle, user info, and Start Test button */}
          <div className="flex items-center gap-4">
            <div className="flex items-center bg-muted rounded-lg p-1">
              <Button variant="default" size="sm" className="px-4" disabled>
                Dashboard
              </Button>
              <Button variant="ghost" size="sm" onClick={() => (window.location.href = "/results")} className="px-4">
                Results
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
                <UserIcon className="h-4 w-4 text-white" />
              </div>
              <span className="text-sm font-medium">{userData.name}</span>
            </div>

            <Separator orientation="vertical" className="h-6" />

            {/* Start Test Button - moved to left side */}
            {currentView === "dashboard" && (
              <Button
                onClick={startTest}
                disabled={testRunning || !inputText.trim() || testPrompts.filter((v) => v.prompt.trim()).length < 1}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {testRunning ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Running...
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    Start Test
                  </>
                )}
              </Button>
            )}
          </div>

          {/* Right side - Cost and permissions */}
          <div className="flex items-center gap-3">
            <Badge
              variant={costData.thisMonth > costData.limit * 0.8 ? "destructive" : "secondary"}
              className="flex items-center gap-1"
            >
              <DollarSign className="h-3 w-3" />${costData.thisMonth}/${costData.limit}
            </Badge>

            {userData.canDeploy && (
              <Badge className="bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700 flex items-center gap-1">
                <Crown className="h-3 w-3" />
                Builder
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 max-w-7xl mx-auto">
        {currentView === "dashboard" && (
          <div className="space-y-6">
            {/* Input Section */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-4">
                  <CardTitle>Test Input</CardTitle>
                  <Button variant="outline" onClick={handleFileUpload} size="sm">
                    <Upload className="mr-2 h-4 w-4" />
                    Upload File
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Paste the text you want to test your prompts against..."
                  className="min-h-24 resize-none"
                />
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.txt,.docx,.md"
                  className="hidden"
                  onChange={(e) => {
                    console.log("File uploaded:", e.target.files?.[0])
                  }}
                />
              </CardContent>
            </Card>

            {/* Current Prompt */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-green-100 rounded-full flex items-center justify-center">
                      <Check className="h-2 w-2 text-green-600" />
                    </div>
                    Current Prompt (Live)
                    <Badge className="bg-green-100 text-green-700">v1.2.1</Badge>
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={currentPrompt}
                  onChange={(e) => setCurrentPrompt(e.target.value)}
                  className="min-h-32 resize-none"
                  placeholder="Enter your current prompt..."
                />
              </CardContent>
            </Card>

            {/* Test Variants */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-4">
                  <CardTitle className="flex items-center gap-2">
                    <GitBranch className="h-5 w-5" />
                    Test Variants
                  </CardTitle>
                  <Button onClick={addVariant} disabled={testPrompts.length >= 5} variant="outline" size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Variant
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {testPrompts.map((variant) => {
                    const isExpanded = expandedPrompts[variant.id]
                    return (
                      <div key={variant.id} className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Label className="font-medium">{variant.label}</Label>
                          <Button variant="ghost" size="sm" onClick={() => togglePromptExpansion(variant.id)}>
                            {isExpanded ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
                          </Button>
                          {testPrompts.length > 1 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeVariant(variant.id)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                        <Textarea
                          value={variant.prompt}
                          onChange={(e) => updatePrompt(variant.id, e.target.value)}
                          className={`resize-none transition-all duration-300 ${isExpanded ? "min-h-32" : "min-h-20"}`}
                          placeholder={`Enter ${variant.label} prompt...`}
                        />
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {currentView === "deploy" && <DeployView />}
      </div>
    </div>
  )
}
