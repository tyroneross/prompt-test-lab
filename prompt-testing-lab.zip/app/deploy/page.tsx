"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Zap, Code, FileText, UserIcon, Target, DollarSign, Crown, Check, AlertTriangle, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function DeployPage() {
  const searchParams = useSearchParams()
  const winnerId = searchParams.get("winner")

  const [selectedApp, setSelectedApp] = useState("Atomize News")
  const [deploySuccess, setDeploySuccess] = useState(false)
  const [undoTimer, setUndoTimer] = useState<number | null>(null)

  // Mock data - in real app this would come from API based on winnerId
  const [selectedVariant] = useState({
    id: Number.parseInt(winnerId || "1"),
    label: "Test Variant B",
    prompt: "Create an attention-grabbing headline and summary for this news story:",
    score: 94,
  })

  const [currentPrompt] = useState("Summarize this news in an engaging headline and brief:")

  const [outputs] = useState({
    current:
      "🚀 GPT-5 Breakthrough: OpenAI's Latest AI Shows Human-Level Reasoning\n\nOpenAI has unveiled GPT-5, marking a significant leap in artificial intelligence capabilities with enhanced logical reasoning that rivals human cognition.",
    new: "🔥 GAME CHANGER: OpenAI's GPT-5 Achieves Human-Level Reasoning\n\nIn a stunning development that could reshape the AI landscape, OpenAI has released GPT-5 with unprecedented reasoning capabilities that match human cognitive performance.",
  })

  const [userData] = useState({ name: "Alex Chen", canDeploy: true, email: "alex@atomize.ai" })
  const [apps] = useState([
    { id: "atomize", name: "Atomize News", version: "v1.2.1" },
    { id: "summarizer", name: "Content Summarizer", version: "v0.8.3" },
  ])
  const [costData] = useState({ thisMonth: 18.73, limit: 25.0, lastTest: 0.34 })

  const deployPrompt = () => {
    setDeploySuccess(true)
    setUndoTimer(300) // 5 minutes
    toast({
      title: "Deployment successful",
      description: "v1.2.2 has been deployed successfully.",
    })
    setTimeout(() => setDeploySuccess(false), 8000)
  }

  // Countdown timer for undo
  useEffect(() => {
    if (undoTimer && undoTimer > 0) {
      const timer = setTimeout(() => setUndoTimer(undoTimer - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [undoTimer])

  return (
    <div className="min-h-screen bg-background">
      {/* Fixed Header */}
      <div className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center justify-between px-6">
          {/* Left side - Navigation and info */}
          <div className="flex items-center gap-4">
            <div className="flex items-center bg-muted rounded-lg p-1">
              <Button variant="ghost" size="sm" onClick={() => (window.location.href = "/")} className="px-4">
                Dashboard
              </Button>
              <Button variant="ghost" size="sm" onClick={() => (window.location.href = "/results")} className="px-4">
                Results
              </Button>
              <Button variant="default" size="sm" className="px-4" disabled>
                Deploy
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
                <UserIcon className="h-4 w-4 text-white" />
              </div>
              <span className="text-sm font-medium">{userData.name}</span>
            </div>

            <div className="flex items-center gap-2">
              <Select value={selectedApp} onValueChange={setSelectedApp}>
                <SelectTrigger className="w-48">
                  <div className="flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    <SelectValue />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  {apps.map((app) => (
                    <SelectItem key={app.id} value={app.name}>
                      {app.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Badge variant="outline">{apps.find((a) => a.name === selectedApp)?.version || "v1.0.0"}</Badge>
            </div>
          </div>

          {/* Right side - Cost and permissions */}
          <div className="flex items-center gap-3">
            <Badge
              variant={costData.thisMonth > costData.limit * 0.8 ? "destructive" : "secondary"}
              className="flex items-center gap-1"
            >
              <DollarSign className="h-3 w-3" />${costData.thisMonth}/${costData.limit}
            </Badge>

            {userData.canDeploy && (
              <Badge className="bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700 flex items-center gap-1">
                <Crown className="h-3 w-3" />
                Builder
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Success Toast */}
      {deploySuccess && (
        <div className="fixed top-4 right-4 z-50 max-w-sm">
          <Alert className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20">
            <Check className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-900 dark:text-green-100">Deployment Successful!</AlertTitle>
            <AlertDescription className="text-green-700 dark:text-green-300">
              v1.2.2 deployed successfully. Undo available for{" "}
              {undoTimer && `${Math.floor(undoTimer / 60)}:${(undoTimer % 60).toString().padStart(2, "0")}`}
              <div className="flex gap-2 mt-2">
                <Button size="sm" variant="outline" className="h-7 bg-transparent">
                  <RotateCcw className="mr-1 h-3 w-3" />
                  Undo
                </Button>
                <Button size="sm" variant="ghost" className="h-7" onClick={() => setDeploySuccess(false)}>
                  Dismiss
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* Main Content */}
      <div className="p-6 max-w-7xl mx-auto">
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Zap className="h-6 w-6 text-blue-600" />
              <h1 className="text-3xl font-bold">Deploy Review</h1>
            </div>
          </div>

          {/* Impact Warning */}
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>High Impact Deployment</AlertTitle>
            <AlertDescription>
              This deployment will change ~47% of outputs. Review the changes carefully before proceeding.
            </AlertDescription>
          </Alert>

          {/* Deploy Preview */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl">{selectedApp} → v1.2.2</CardTitle>
                  <CardDescription>
                    Deploying {selectedVariant.label} (Score: {selectedVariant.score}%) as new base prompt
                  </CardDescription>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium">Impact Preview</p>
                  <p className="text-sm text-muted-foreground">~47% output change detected</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Prompt Changes */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Code className="h-4 w-4" />
                    Prompt Changes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                        Current (v1.2.1)
                      </Label>
                      <div className="mt-2 p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                        <pre className="text-sm font-mono whitespace-pre-wrap">{currentPrompt}</pre>
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                        New (v1.2.2)
                      </Label>
                      <div className="mt-2 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                        <pre className="text-sm font-mono whitespace-pre-wrap">{selectedVariant.prompt}</pre>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Output Preview */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Output Preview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                        Current Output
                      </Label>
                      <div className="mt-2 p-4 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800">
                        <div className="text-sm whitespace-pre-wrap">{outputs.current}</div>
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                        New Output
                      </Label>
                      <div className="mt-2 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                        <div className="text-sm whitespace-pre-wrap">{outputs.new}</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>

          {/* Deploy Button */}
          <div className="flex justify-center">
            <Button onClick={deployPrompt} className="bg-green-600 hover:bg-green-700" size="lg">
              <Zap className="mr-2 h-5 w-5" />
              Deploy v1.2.2
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
